import { useAuth } from "../../auth/AuthContext";
import { useNavigate } from "react-router-dom";
import styles from "./perfil.module.css";

function Perfil() {
  const { usuario, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  return (
    <section className={styles.page}>
      <div className={styles.card}>
        <div className={styles.avatar}>
          {usuario?.displayName
            ? usuario.displayName[0].toUpperCase()
            : usuario?.email[0].toUpperCase()}
        </div>

        <h1 className={styles.nombre}>
          {usuario?.displayName || "Usuario"}
        </h1>
        <p className={styles.email}>{usuario?.email}</p>

        <div className={styles.info}>
          <div className={styles.fila}>
            <span className={styles.label}>ID de cuenta</span>
            <span className={styles.valor}>{usuario?.uid?.slice(0, 12)}...</span>
          </div>
          <div className={styles.fila}>
            <span className={styles.label}>Email verificado</span>
            <span className={styles.valor}>
              {usuario?.emailVerified ? "✅ Sí" : "❌ No"}
            </span>
          </div>
        </div>

        <div className={styles.botones}>
          <button
            className={styles.btnGestion}
            onClick={() => navigate("/gestion")}
          >
            Ir a Gestión de Productos
          </button>
          <button className={styles.btnLogout} onClick={handleLogout}>
            Cerrar sesión
          </button>
        </div>
      </div>
    </section>
  );
}

export default Perfil;
