import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import CartWidget from "./CartWidget";
import { useAuth } from "../../auth/AuthContext";
import styles from "./navbar.module.css";

function NavBar() {
  const { isAuthenticated, usuario, logout } = useAuth();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate("/");
    setMenuOpen(false);
  };

  return (
    <nav className={styles.nav}>
      <button
        className={styles.menuToggle}
        onClick={() => setMenuOpen(!menuOpen)}
        aria-label="Menú"
      >
        ☰
      </button>

      <div className={`${styles.links} ${menuOpen ? styles.open : ""}`}>
        <Link to="/" onClick={() => setMenuOpen(false)}>Inicio</Link>
        <Link to="/productos" onClick={() => setMenuOpen(false)}>Productos</Link>
        <Link to="/contacto" onClick={() => setMenuOpen(false)}>Contacto</Link>

        {isAuthenticated ? (
          <>
            <Link to="/perfil" onClick={() => setMenuOpen(false)}>
              👤 {usuario?.displayName || "Perfil"}
            </Link>
            <Link to="/gestion" onClick={() => setMenuOpen(false)}>Gestión</Link>
            <button className={styles.logoutBtn} onClick={handleLogout}>
              Salir
            </button>
          </>
        ) : (
          <>
            <Link to="/login" onClick={() => setMenuOpen(false)}>Iniciar sesión</Link>
            <Link to="/registro" onClick={() => setMenuOpen(false)}>Registrarse</Link>
          </>
        )}
      </div>

      <Link to="/carrito" className={styles.cartLink}>
        <CartWidget />
      </Link>
    </nav>
  );
}

export default NavBar;
